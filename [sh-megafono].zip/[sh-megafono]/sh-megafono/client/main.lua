-- 🔊 Creación del efecto de audio del megáfono (submix)
local radioEffectId = CreateAudioSubmix("Megaphone")

-- Activamos el efecto tipo radio
SetAudioSubmixEffectRadioFx(radioEffectId, 0)
SetAudioSubmixEffectParamInt(radioEffectId, 0, GetHashKey('default'), 1)

-- 🎛️ Configuración de frecuencias y mezcla del sonido
-- Estos valores ajustan cómo se escucha la voz: tono, nitidez, eco, etc.
SetAudioSubmixEffectParamFloat(radioEffectId, 0, GetHashKey("freq_hi"), 7000.0) -- Frecuencias altas (claridad)
SetAudioSubmixEffectParamFloat(radioEffectId, 0, GetHashKey("freq_low"), 289.0)  -- Frecuencias bajas (grave)
SetAudioSubmixEffectParamFloat(radioEffectId, 0, GetHashKey("rm_mix"), 0.16)      -- Mezcla/eco del efecto
SetAudioSubmixEffectParamFloat(radioEffectId, 0, GetHashKey("o_freq_lo"), 548.0)  -- Ajuste de salida

-- 🔈 Configuración de salida del sonido (canales frontales)
SetAudioSubmixOutputVolumes(
    radioEffectId,
    0,
    1.0, -- Volumen del canal frontal izquierdo
    1.0, -- Volumen del canal frontal derecho
    0.0, -- Volumen del canal trasero izquierdo
    0.0, -- Volumen del canal trasero derecho
    1.0, -- Canal adicional 5
    1.0  -- Canal adicional 6
)
AddAudioSubmixOutput(radioEffectId, 0)

-- 🔍 Verifica si el jugador está en un vehículo policial o helicóptero autorizado
function IsInPoiceVehOrHeli(ped)
	local veh = GetVehiclePedIsIn(ped, false)
	local model = GetEntityModel(veh)
	return Config.PoliceVehicles[model], Config.Helis[model], GetVehicleClass(veh) == 18
end

local megaphone = false

-- 🔁 Restaura el audio del jugador cuando deja de usar el megáfono
function restoreDefaultSubmix(plyServerId)
	local submix = Player(plyServerId).state.submix
	if not submix then
		MumbleSetSubmixForServerId(plyServerId, -1)
		return
	end
	MumbleSetSubmixForServerId(plyServerId, submixEffect)
end

-- 🎤 Alterna el uso del megáfono (activar/desactivar efecto y volumen)
function toggleMegaphone(plySource, enabled)
	if enabled then
		-- Aumenta el volumen general de la voz (por encima del rango normal)
		-- ⚠️ Esto ignora el efecto 3D de distancia (suena igual de fuerte dentro del rango)
		MumbleSetVolumeOverrideByServerId(plySource, 3.0)
		MumbleSetSubmixForServerId(plySource, radioEffectId)
	elseif not enabled then
		if GetConvarInt('voice_enableSubmix', 1) == 1 then
			SetTimeout(10, function()
				restoreDefaultSubmix(plySource)
			end)
		end
		MumbleSetVolumeOverrideByServerId(plySource, -1.0) -- Restaura volumen normal
	end
end

-- 🧩 Evento que activa/desactiva el efecto del megáfono para todos los clientes
function setTalkingOnMegaphone(plySource, enabled)
	toggleMegaphone(plySource, enabled)
end
RegisterNetEvent('pma-voice:setTalkingMegaphone', setTalkingOnMegaphone)

-- 🧠 Comando para ACTIVAR el megáfono
RegisterCommand('+useMegaphone', function()
	local ped = PlayerPedId()
	local police, heli, emveh = IsInPoiceVehOrHeli(ped)

	if not megaphone and (police or heli or emveh) then
        megaphone = true
		TriggerServerEvent('pma-voice:setTalkingMegaphone', true)

        -- Cambia el rango de voz mientras el megáfono está activo
		exports['pma-voice']:overrideProximityRange(
			heli and Config.HeliMegaphoneProximity or Config.MegaphoneProximity,
			false
		)

        -- Mantiene el control mientras el jugador habla
		CreateThread(function()
			local checkFailed = false
			while megaphone do
				if IsEntityDead(ped) then
					checkFailed = true
					break
				end
				SetControlNormal(0, 249, 1.0)
				SetControlNormal(1, 249, 1.0)
				SetControlNormal(2, 249, 1.0)
				Wait(0)
				if checkFailed then
					ExecuteCommand("-useMegaphone")
				end
            end
		end)
	end
end, false)

-- 🧠 Comando para DESACTIVAR el megáfono
RegisterCommand('-useMegaphone', function()
	megaphone = false
	MumbleClearVoiceTargetPlayers(1) -- Limpia los objetivos de voz activos
	TriggerServerEvent('pma-voice:setTalkingMegaphone', false)
	exports['pma-voice']:clearProximityOverride()
end, false)

-- 🔑 Mapeo de la tecla por defecto (puedes cambiarla en Config.DefaultKeybind)
RegisterKeyMapping('+useMegaphone', 'Usar megáfono', 'keyboard', Config.DefaultKeybind)
