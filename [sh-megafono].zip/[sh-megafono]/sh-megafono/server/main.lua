-- Servidor del recurso sh-megafono
-- Este archivo se encarga de sincronizar el efecto del megáfono entre todos los jugadores.

-- 🔁 Evento que se ejecuta cuando un jugador activa o desactiva el megáfono.
-- Envía una notificación a todos los demás jugadores para aplicar el efecto de audio.
function setTalkingMegaphone(talking)
	for player, _ in pairs(GetPlayers()) do
		if player ~= source then
			TriggerClientEvent('pma-voice:setTalkingMegaphone', player, source, talking)
		end
	end
end

-- 🔔 Registro del evento desde el cliente.
-- Cuando un jugador usa el megáfono, se avisa al servidor para que lo propague.
RegisterNetEvent('pma-voice:setTalkingMegaphone', setTalkingMegaphone)
