Config = {}

-- 🔹 Tecla por defecto para activar el megáfono
Config.DefaultKeybind = 'K'

-- 🔹 Vehículos que podrán usar el megáfono (agrega el nombre del modelo)
Config.PoliceVehicles = {
    --[`buffalo4`] = true,   -- 🚓 Ejemplo de vehículo con megáfono permitido
}

-- 🔹 Helicópteros (o aviones, aunque no tendría mucho sentido)
Config.Helis = {
    [`polmav`] = true,
}

-- 🔹 Distancia en metros a la que se escuchará el megáfono
-- 📢 Puedes ajustar estos valores para aumentar o reducir el rango del sonido
Config.MegaphoneProximity = 35.0
Config.HeliMegaphoneProximity = 37.0

-- 🔸 IMPORTANTE:
-- Agrega esta línea en tu server.cfg si aún no está:
-- setr voice_useNativeAudio true
-- (Esto mejora la calidad de audio nativo de Mumble y extiende el rango de voz)

-- 🔧 Las siguientes funciones solo se necesitan del lado del cliente
if not IsDuplicityVersion() then
    -- Crea un submezclador de audio (submix) para aplicar efectos
	function CreateAudioSubmix(name)
		return Citizen.InvokeNative(0x658d2bc8, name, Citizen.ResultAsInteger())
	end

    -- Añade una salida de audio al submix creado
	function AddAudioSubmixOutput(submixId, outputSubmixId)
		Citizen.InvokeNative(0xAC6E290D, submixId, outputSubmixId)
	end

    -- Asigna un submix a un jugador (para modificar su audio)
	function MumbleSetSubmixForServerId(serverId, submixId)
		Citizen.InvokeNative(0xFE3A3054, serverId, submixId)
	end

    -- Controla parámetros de efectos (intensidad, frecuencias, etc.)
	function SetAudioSubmixEffectParamFloat(submixId, effectSlot, paramIndex, paramValue)
		Citizen.InvokeNative(0x9A209B3C, submixId, effectSlot, paramIndex, paramValue)
	end

    function SetAudioSubmixEffectParamInt(submixId, effectSlot, paramIndex, paramValue)
        Citizen.InvokeNative(0x77FAE2B8, submixId, effectSlot, paramIndex, paramValue)
    end

    -- Aplica un efecto tipo radio (megáfono o walkie)
    function SetAudioSubmixEffectRadioFx(submixId, effectSlot)
        Citizen.InvokeNative(0xAAA94D53, submixId, effectSlot)
    end

    -- Control del volumen en los canales de salida (izquierdo, derecho, traseros, etc.)
    function SetAudioSubmixOutputVolumes(submixId, outputSlot, frontLeftVolume, frontRightVolume, rearLeftVolume,
                                            rearRightVolume, channel5Volume, channel6Volume)
        Citizen.InvokeNative(0x825DC0D1, submixId, outputSlot, frontLeftVolume, frontRightVolume, rearLeftVolume,
            rearRightVolume, channel5Volume, channel6Volume)
    end
end
