# QB-core 
- Megafono para usar dentro de los carros policiales o culquier otro que se efina dentro del shared. 
poner ensure sh-megafono en el cfg y a correr